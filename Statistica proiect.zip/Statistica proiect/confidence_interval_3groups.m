%% 1. Load and Clean Dataset
filename = 'minimum_wage_eu_dataset.csv';
data = readtable(filename);

% Curatare standard
data(:, 1:7) = [];
data(:, end-4:end) = [];
data(:, 4) = [];
newNames = {'CountryCode','Country','TimePeriod','Value'};
data.Properties.VariableNames = newNames;

% Conversii
data.Country = string(data.Country); 
timePeriodStr = string(data.TimePeriod); 
data.TimePeriod = categorical(data.TimePeriod);
data.Value = str2double(string(data.Value));

%% 2. Procesare Timp (Numeric)
tokens = regexp(timePeriodStr, '(\d+)-S(\d)', 'tokens');
timeNumeric = zeros(height(data), 1);
for i = 1:length(tokens)
    if ~isempty(tokens{i})
        y = str2double(tokens{i}{1}{1});
        s = str2double(tokens{i}{1}{2});
        timeNumeric(i) = y + (s-1)*0.5; 
    else
        timeNumeric(i) = NaN;
    end
end
data.TimeNumeric = timeNumeric;
uniqueTimes = sort(unique(timeNumeric(~isnan(timeNumeric))));

%% 3. ALGORITM DE CLASIFICARE AUTOMATA (Low / Medium / High)
% Identificam toate tarile
allCountries = unique(data.Country(~isnan(data.Value) & data.Country ~= ""));

% Determinam salariul maxim (cel mai recent) pentru fiecare tara
maxWages = zeros(length(allCountries), 1);
for i = 1:length(allCountries)
    cVals = data.Value(strcmp(data.Country, allCountries(i)));
    maxWages(i) = max(cVals); % Luam maximul istoric (de obicei 2024/2025)
end

% Sortam tarile dupa salariu
[sortedWages, sortIdx] = sort(maxWages);
sortedCountries = allCountries(sortIdx);

% Impartim in 3 grupe egale (Tertile)
n = length(sortedCountries);
n_chunk = floor(n / 3);

groupLow_Countries = sortedCountries(1:n_chunk);           % Prima treime (cei mai saraci)
groupMed_Countries = sortedCountries(n_chunk+1:2*n_chunk); % A doua treime
groupHigh_Countries = sortedCountries(2*n_chunk+1:end);    % A treia treime (cei mai bogati)

% Definim structura pentru bucla de plotare
groups = {groupLow_Countries, groupMed_Countries, groupHigh_Countries};
groupNames = {'Low Income Group', 'Medium Income Group', 'High Income Group'};
% Culori semafor: Rosu (Low), Galben/Portocaliu (Med), Verde (High)
groupColors = [0.8, 0.2, 0.2;  0.9, 0.6, 0.0;  0.2, 0.6, 0.2]; 

%% 4. Afisare Componenta Grupuri in Consola
fprintf('\n======================================================\n');
fprintf(' CLASIFICARE AUTOMATA BAZATA PE DATELE RECENTE\n');
fprintf('======================================================\n');
for g = 1:3
    fprintf('\n GRUP: %s (%d tari)\n', groupNames{g}, length(groups{g}));
    fprintf(' Membri: ');
    fprintf('%s, ', groups{g});
    fprintf('\n');
end

%% 5. Generare Grafice si Raport Statistic
markerSizeRaw = 20;  
markerSizeMean = 8;  
lineWidthCI = 2;     

for g = 1:length(groups)
    currentCountries = groups{g};
    currentGroupName = groupNames{g};
    thisGroupColor = groupColors(g, :);
    
    % --- HEADER TABEL ---
    fprintf('\n------------------------------------------------------\n');
    fprintf(' STATISTICI: %s\n', currentGroupName);
    fprintf('------------------------------------------------------\n');
    fprintf('%-12s | %-15s | %-15s\n', 'Perioada', 'Media (Mean)', 'Marja (+/-)');
    
    % --- CALCUL PER TIMP ---
    groupMeans = [];
    groupErrs = [];
    validTimes = [];
    
    for t = 1:length(uniqueTimes)
        currentTime = uniqueTimes(t);
        
        % Selectam doar tarile din grupul curent
        rows = ismember(data.Country, currentCountries) & (data.TimeNumeric == currentTime);
        vals = data.Value(rows);
        vals(isnan(vals)) = [];
        
        if ~isempty(vals)
            n = length(vals);
            avg = mean(vals);
            
            % Calcul Interval Incredere
            if n > 1
                sd = std(vals);
                sem = sd / sqrt(n);
                ts = tinv(0.975, n-1);
                margin = ts * sem;
            else
                margin = 0;
            end
            
            % Print doar pentru date recente (sa nu umplem consola, optional)
            if currentTime >= 2023 
                 % Formatare label
                yPart = floor(currentTime);
                if (currentTime - yPart) > 0.1, sPart = 'S2'; else, sPart = 'S1'; end
                tLabel = sprintf('%d-%s', yPart, sPart);
                fprintf('%-12s | %-15.1f | %-15.1f\n', tLabel, avg, margin);
            end
            
            groupMeans = [groupMeans; avg];
            groupErrs = [groupErrs; margin];
            validTimes = [validTimes; currentTime];
        end
    end
    
    % ---------------------------------------------------------
    % PLOT A: STATS (Mean + CI) - STIL "CURAT"
    % ---------------------------------------------------------
    if ~isempty(validTimes)
        figure('Name', ['Stats: ' currentGroupName], 'Color', 'w');
        hold on; grid on;
        
        % Error Bar
        eb = errorbar(validTimes, groupMeans, groupErrs, ...
            'o', 'Color', thisGroupColor, ...         
            'MarkerFaceColor', thisGroupColor, ...    
            'MarkerEdgeColor', thisGroupColor, ...    
            'LineWidth', lineWidthCI, ...
            'MarkerSize', markerSizeMean, ...
            'CapSize', 10, ...                        
            'LineStyle', 'none');                     
        
        % Adaugam o linie subtire punctata pentru a ghida ochiul (trend)
        plot(validTimes, groupMeans, '--', 'Color', [thisGroupColor, 0.4], 'LineWidth', 1);

        title(['Media și Intervalul: ' currentGroupName]);
        xlabel('Anul');
        ylabel('Salariu Minim (EUR)');
        xlim([1998, 2026]);
        xticks(1999:2:2025);
        xtickangle(45);
        
        legend(eb, sprintf('Media Grupului \\pm 95%% CI\n(n = %d țări)', length(currentCountries)), 'Location', 'northwest');
        hold off;
        
        % ---------------------------------------------------------
        % PLOT B: RAW DATA - STIL "DETALIAT"
        % ---------------------------------------------------------
        figure('Name', ['Raw: ' currentGroupName], 'Color', 'w');
        hold on; grid on;
        
        subColors = parula(length(currentCountries)); 
        legendEntries = [];
        legendLabels = {};
        
        for c = 1:length(currentCountries)
            countryName = currentCountries{c};
            rows = strcmp(data.Country, countryName);
            
            sc = scatter(data.TimeNumeric(rows), data.Value(rows), markerSizeRaw, ...
                'MarkerEdgeColor', 'none', ...       
                'MarkerFaceColor', subColors(c,:), ... 
                'MarkerFaceAlpha', 0.7, ...          
                'DisplayName', countryName);
                
            legendEntries(end+1) = sc;
            legendLabels{end+1} = countryName;
        end
        
        % Re-plotam media peste raw data cu negru, discret
        plot(validTimes, groupMeans, '-k', 'LineWidth', 1.5, 'Color', [0 0 0 0.5]);
        
        title(['Distribuția Țărilor: ' currentGroupName]);
        xlabel('Anul');
        ylabel('Salariu Minim (EUR)');
        xlim([1998, 2026]);
        xticks(1999:2:2025);
        xtickangle(45);
        
        % Legenda pe coloane daca sunt multe tari
        legend(legendEntries, legendLabels, 'Location', 'bestoutside', 'NumColumns', 1);
        hold off;
    end
end