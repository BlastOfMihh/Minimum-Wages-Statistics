%% 1. Incarcare si Pregatire Date
filename = 'minimum_wage_eu_dataset.csv';
data = readtable(filename);

% Curatenie coloane
data(:, [1:7, end-4:end]) = [];
data(:, 4) = [];
data.Properties.VariableNames = {'CountryCode','Country','TimePeriod','Value'};

% Fix pentru tipuri de date
data.CountryCode = string(data.CountryCode);
data.Value = str2double(string(data.Value));

% Procesare Timp
tokens = regexp(string(data.TimePeriod), '(\d+)-S(\d)', 'tokens');
timeNumeric = zeros(height(data), 1);
for i = 1:length(tokens)
    if ~isempty(tokens{i})
        y = str2double(tokens{i}{1}{1}); s = str2double(tokens{i}{1}{2});
        timeNumeric(i) = y + (s-1)*0.5; 
    else, timeNumeric(i) = NaN; end
end
data.TimeNumeric = timeNumeric;
data = data(~isnan(data.Value) & ~isnan(data.TimeNumeric), :);

%% 2. Selectie Date: Romania (RO) vs Bulgaria (BG)
target1 = "RO";
target2 = "BG";

data1 = data(data.CountryCode == target1, :);
data2 = data(data.CountryCode == target2, :);

% Intersectie pe ani comuni
[commonTime, idx1, idx2] = intersect(data1.TimeNumeric, data2.TimeNumeric);
vals1 = data1.Value(idx1);
vals2 = data2.Value(idx2);

%% 3. PARTEA A: Testul de Corelatie (Validarea Statistica)
fprintf('==============================================\n');
fprintf('     ANALIZA STATISTICA: %s vs %s\n', target1, target2);
fprintf('==============================================\n');

% 1. Calcul Rho
R_matrix = corrcoef(vals1, vals2);
rho = R_matrix(1,2);
n = length(vals1);

% 2. Calcul T-Statistic (Manual)
% Formula: t = rho * sqrt(n-2) / sqrt(1-rho^2)
t_stat = rho * sqrt(n - 2) / sqrt(1 - rho^2);

% 3. Valoarea Critica (din tabel)
alpha = 0.05;
df = n - 2; 
t_critical = tinv(1 - alpha/2, df); 

fprintf('\n[PARTEA 1] TESTUL DE CORELATIE (T-Test for Pearson rho)\n');
fprintf('------------------------------------------------------\n');
fprintf('Ipoteza Nula (H0): Nu exista corelatie (rho=0)\n');
fprintf('Coeficientul rho:  %.4f\n', rho);
fprintf('Scor t calculat:   %.4f\n', t_stat);
fprintf('Scor t critic:     %.4f (pentru alpha=0.05)\n', t_critical);

if abs(t_stat) > t_critical
    fprintf('REZULTAT: |t_calc| > t_crit => RESPINGEM H0.\n');
    fprintf('CONCLUZIE: Corelatia este STATISTIC SEMNIFICATIVA.\n');
else
    fprintf('REZULTAT: Nu putem respinge H0.\n');
end

%% 4. PARTEA B: Regresia Liniara (Modelare si Grafic)
fprintf('\n[PARTEA 2] MODELUL DE REGRESIE LINIARA\n');
fprintf('------------------------------------------------------\n');

% Calculam modelul: BG = a + b * RO
mdl = fitlm(vals1, vals2);
intercept = mdl.Coefficients.Estimate(1);
panta = mdl.Coefficients.Estimate(2);
r_sq = mdl.Rsquared.Ordinary;

fprintf('Ecuatia: Salariu_%s = %.2f + %.2f * Salariu_%s\n', target2, intercept, panta, target1);
fprintf('R-squared: %.4f (Modelul explica %.1f%% din variatie)\n', r_sq, r_sq*100);

% -- GRAFIC --
figure;
scatter(vals1, vals2, 60, 'filled', 'MarkerFaceColor', [0 0.4470 0.7410]); % Puncte albastre
hold on;

% Desenam linia de regresie
h = lsline; 
h.Color = [0.8500 0.3250 0.0980]; % Linie rosie
h.LineWidth = 2.5;

% Estetica
title(['Relatia Salarii: ' char(target1) ' vs ' char(target2)], 'FontSize', 14);
subtitle({['\rho = ' num2str(rho, '%.3f') ', R^2 = ' num2str(r_sq, '%.3f')], ...
          ['Ecuatie: y = ' num2str(panta, '%.2f') 'x + ' num2str(intercept, '%.2f')]}, 'FontSize', 10);
xlabel(['Salariu Minim ' char(target1) ' (EUR)'], 'FontSize', 12, 'FontWeight', 'bold');
ylabel(['Salariu Minim ' char(target2) ' (EUR)'], 'FontSize', 12, 'FontWeight', 'bold');
grid on;
legend({'Date Observate', 'Linie de Regresie'}, 'Location', 'best');
hold off;