%% 1. Load and Clean Dataset
filename = 'minimum_wage_eu_dataset.csv';
data = readtable(filename);

% Remove unnecessary columns
data(:, 1:7) = [];
data(:, end-4:end) = [];
data(:, 4) = [];

% Rename columns
newNames = {'CountryCode','Country','TimePeriod','Value'};
data.Properties.VariableNames = newNames;

% Convert types
data.CountryCode = categorical(data.CountryCode);
data.Country = string(data.Country); % String pentru manipulare usoara
timePeriodStr = string(data.TimePeriod); 
data.TimePeriod = categorical(data.TimePeriod);
data.Value = str2double(string(data.Value));

%% 2. Procesare Timp (Numeric)
tokens = regexp(timePeriodStr, '(\d+)-S(\d)', 'tokens');
timeNumeric = zeros(height(data), 1);

for i = 1:length(tokens)
    if ~isempty(tokens{i})
        y = str2double(tokens{i}{1}{1});
        s = str2double(tokens{i}{1}{2});
        timeNumeric(i) = y + (s-1)*0.5; 
    else
        timeNumeric(i) = NaN;
    end
end
data.TimeNumeric = timeNumeric;
uniqueTimes = unique(timeNumeric);
uniqueTimes(isnan(uniqueTimes)) = [];
uniqueTimes = sort(uniqueTimes);

%% 3. Definire "Grupul Total" (Toate Tarile)
% Identificam toate tarile care au date valide
allCountries = unique(data.Country(~isnan(data.Value)));
allCountries(allCountries == "") = [];

% Setam culoarea principala pentru "Media Europeana" (Un albastru regal)
mainColor = [0, 0.2, 0.6]; 

%% 4. Calcul Statistici Agregate (Global)

globalMeans = [];
globalErrs = [];
validTimes = [];
nCountriesPerTime = [];

% Header Consola
fprintf('\n=================================================================\n');
fprintf(' RAPORT GLOBAL: TOATE TARILE (%d tari identificate)\n', length(allCountries));
fprintf('=================================================================\n');
fprintf('%-12s | %-10s | %-12s | %-15s | %-15s\n', 'Perioada', 'N (Tari)', 'Media (EUR)', 'Marja (+/-)', 'Interval (Min-Max)');
fprintf('-----------------------------------------------------------------\n');

for t = 1:length(uniqueTimes)
    currentTime = uniqueTimes(t);
    
    % Luam TOATE valorile din anul respectiv, indiferent de tara
    rows = (data.TimeNumeric == currentTime);
    vals = data.Value(rows);
    vals(isnan(vals)) = [];
    
    if ~isempty(vals)
        n = length(vals);
        avg = mean(vals);
        
        % Calcul Interval Incredere (t-distribution)
        if n > 1
            sd = std(vals);
            sem = sd / sqrt(n);
            ts = tinv(0.975, n-1);
            margin = ts * sem;
        else
            margin = 0;
        end
        
        % Salvare date
        globalMeans = [globalMeans; avg];
        globalErrs = [globalErrs; margin];
        validTimes = [validTimes; currentTime];
        nCountriesPerTime = [nCountriesPerTime; n];
        
        % Printare in consola
        % Formatare eticheta timp
        yearPart = floor(currentTime);
        if (currentTime - yearPart) > 0.1, semPart = 'S2'; else, semPart = 'S1'; end
        timeLabel = sprintf('%d-%s', yearPart, semPart);
        
        fprintf('%-12s | %-10d | %-12.1f | %-15.1f | [%.0f - %.0f]\n', ...
            timeLabel, n, avg, margin, avg-margin, avg+margin);
    end
end
fprintf('-----------------------------------------------------------------\n');

%% 5. Plot 1: Statistica Globala (Media + Intervalul de Incredere)

figure('Name', 'Global Stats: Media Europeana', 'Color', 'w');
hold on; grid on;

% Error Bar Discret
eb = errorbar(validTimes, globalMeans, globalErrs, ...
    'o', 'Color', mainColor, ...
    'MarkerFaceColor', mainColor, ...
    'MarkerEdgeColor', mainColor, ...
    'LineWidth', 2, ...
    'MarkerSize', 8, ...
    'CapSize', 10, ...
    'LineStyle', 'none');

title({'Media Salariului Minim la Nivel European', '(Toate țările agregate într-un singur grup)'}, 'FontSize', 12);
xlabel('Anul');
ylabel('Salariu Minim (EUR)');
xlim([1998, 2026]);
xticks(1999:2:2025);
xtickangle(45);

% Adaugam o legenda cu ultima valoare
legend(eb, sprintf('Media UE (Est+Vest) \\pm 95%% CI\n(Dispersie mare datorită inegalității)'), 'Location', 'northwest');
hold off;

%% 6. Plot 2: Raw Data Cloud (Distributia Tuturor Tarilor)

figure('Name', 'Global Raw: Distributia Tuturor Tarilor', 'Color', 'w');
hold on; grid on;

% Pentru raw data, folosim o paleta de culori variata
nTotalCountries = length(allCountries);
colors = jet(nTotalCountries); 

% Plotam punctele fiecarei tari in spate
legendEntries = [];
% Din cauza ca sunt multe tari, nu le punem pe toate in legenda (ar ocupa tot ecranul),
% dar le desenam pe toate.
for i = 1:nTotalCountries
    cCountry = allCountries(i);
    rows = strcmp(data.Country, cCountry);
    
    sc = scatter(data.TimeNumeric(rows), data.Value(rows), 25, ...
        'MarkerEdgeColor', 'none', ...
        'MarkerFaceColor', colors(i,:), ...
        'MarkerFaceAlpha', 0.6, ... % Transparenta pentru a vedea densitatea
        'DisplayName', cCountry);
end

% Plotam Media Globala peste ele, ca referinta
plot(validTimes, globalMeans, '-k', 'LineWidth', 2, 'DisplayName', 'Media Globală');

title({'Distribuția Tuturor Țărilor vs Media Globală', '(Fiecare punct este o țară)'});
xlabel('Anul');
ylabel('Salariu Minim (EUR)');
xlim([1998, 2026]);
xticks(1999:2:2025);
xtickangle(45);

% Nota pe grafic in loc de legenda imensa
text(1999, 2000, 'Fiecare punct colorat = O țară', 'FontSize', 10, 'BackgroundColor', 'w');
text(1999, 1850, 'Linia Neagră = Media calculată', 'FontSize', 10, 'BackgroundColor', 'w');

hold off;