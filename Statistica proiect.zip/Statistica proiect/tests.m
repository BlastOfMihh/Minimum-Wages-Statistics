%% 1. Load and Clean Data
filename = 'minimum_wage_eu_dataset.csv';
data = readtable(filename);

% Clean columns
data(:, 1:7) = []; data(:, end-4:end) = []; data(:, 4) = [];
data.Properties.VariableNames = {'CountryCode','Country','TimePeriod','Value'};
data.Country = string(data.Country);
data.Value = str2double(string(data.Value));

% Process Time (Numeric)
tokens = regexp(string(data.TimePeriod), '(\d+)-S(\d)', 'tokens');
timeNumeric = zeros(height(data), 1);
for i = 1:length(tokens)
    if ~isempty(tokens{i})
        y = str2double(tokens{i}{1}{1}); s = str2double(tokens{i}{1}{2});
        timeNumeric(i) = y + (s-1)*0.5; 
    else, timeNumeric(i) = NaN; end
end
data.TimeNumeric = timeNumeric;

% Remove NaNs
data = data(~isnan(data.Value) & ~isnan(data.TimeNumeric), :);

%% ---------------------------------------------------------
%% TEST 1: SIGNIFICANT CORRELATION (As per Lecture Note p.162)
%% ---------------------------------------------------------
% We test the correlation between TIME and WAGE for the whole dataset.
% Hypothesis H0: rho = 0 (No linear correlation)

fprintf('\n======================================================\n');
fprintf(' TEST 1: SIGNIFICANT CORRELATION (Time vs Wage)\n');
fprintf('======================================================\n');

x = data.TimeNumeric;
y = data.Value;
n = length(x);

% Calculate Pearson Correlation Coefficient (rho)
R = corrcoef(x, y);
rho = R(1, 2);

fprintf(' Sample Size (n): %d\n', n);
fprintf(' Pearson Correlation Coefficient (|rho|): %.4f\n', abs(rho));

% Determine Significance Level based on PDF rules
% (Using standard p-value approximations for the thresholds mentioned)
% In the PDF: p < 0.05 (Significant), p < 0.01 (Distinctly), p < 0.001 (Very)

[~, p_val] = corrcoef(x, y);
p_value = p_val(1,2);

fprintf(' P-value associated: %.10f\n', p_value);

fprintf(' CONCLUSION (based on lecture terminology):\n');
if p_value < 0.001
    fprintf(' => The correlation is VERY SIGNIFICANT (|rho| >= rho_0.001).\n');
    fprintf('    (Time strongly predicts the growth of wages).\n');
elseif p_value < 0.01
    fprintf(' => The correlation is DISTINCTLY SIGNIFICANT.\n');
elseif p_value < 0.05
    fprintf(' => The correlation is MODERATELY SIGNIFICANT.\n');
else
    fprintf(' => NOT SIGNIFICANT.\n');
end


%% ---------------------------------------------------------
%% TEST 2: REGRESSION WITH DUMMY VARIABLES (Lecture Note p.11-12)
%% ---------------------------------------------------------
% We will model Wage based on Time AND a Dummy Variable for Group.
% Comparison: "Low Income" (Romania/Bulgaria) vs "High Income" (Germany/Luxembourg)
% Dummy Variable Z: 0 = Low Income, 1 = High Income

fprintf('\n======================================================\n');
fprintf(' TEST 2: REGRESSION WITH DUMMY VARIABLES (ANOVA F-Test)\n');
fprintf('======================================================\n');

% Define Groups
groupLow = ["Bulgaria", "Romania"];
groupHigh = ["Germany", "Luxembourg"];

% Filter Data
dataLow = data(ismember(data.Country, groupLow), :);
dataHigh = data(ismember(data.Country, groupHigh), :);

% Create Dummy Variable Z
% Z = 0 for Low Group
% Z = 1 for High Group
X_low = dataLow.TimeNumeric;
Y_low = dataLow.Value;
Z_low = zeros(length(X_low), 1);

X_high = dataHigh.TimeNumeric;
Y_high = dataHigh.Value;
Z_high = ones(length(X_high), 1);

% Combine Data
X_combined = [X_low; X_high]; % Predictor 1: Time
Z_combined = [Z_low; Z_high]; % Predictor 2: Dummy Group
Y_combined = [Y_low; Y_high]; % Response: Wage

% Fit Linear Regression Model: Wage ~ Time + DummyGroup
% This corresponds to equation y = b0 + b1*x + b2*z
tbl = table(X_combined, Z_combined, Y_combined, 'VariableNames', {'Year', 'GroupDummy', 'Wage'});
mdl = fitlm(tbl, 'Wage ~ Year + GroupDummy');

% Display Results
disp(mdl);

% Extract ANOVA F-Test from the model
anovaParams = anova(mdl, 'summary');
F_stat = anovaParams.F(1);
p_F = anovaParams.pValue(1);

fprintf('------------------------------------------------------\n');
fprintf(' INTERPRETATION OF REGRESSION RESULTS:\n');
fprintf('------------------------------------------------------\n');
fprintf(' 1. Coefficient for GroupDummy: %.2f\n', mdl.Coefficients.Estimate(3));
fprintf('    (This means High Income countries are, on average, %.2f EUR\n', mdl.Coefficients.Estimate(3));
fprintf('     higher than Low Income countries, even after controlling for year).\n\n');

fprintf(' 2. ANOVA F-Test for the Model:\n');
fprintf('    F-Statistic: %.2f\n', F_stat);
fprintf('    P-value: %.10f\n', p_F);

if p_F < 0.05
    fprintf('    CONCLUSION: The model is SIGNIFICANT (p < 0.05).\n');
    fprintf('    The "Dummy Variable" (Group) significantly explains wage variation.\n');
else
    fprintf('    CONCLUSION: The model is NOT significant.\n');
end
fprintf('======================================================\n');