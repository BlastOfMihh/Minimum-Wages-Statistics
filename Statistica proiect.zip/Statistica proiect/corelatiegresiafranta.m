%% Comparatie: Crestere Perfecta vs. Instabilitate
% Incarcare date (Ruleaza doar daca nu le ai deja in workspace)
if ~exist('data', 'var')
    filename = 'minimum_wage_eu_dataset.csv';
    data = readtable(filename);
    data(:, [1:7, end-4:end]) = []; data(:, 4) = [];
    data.Properties.VariableNames = {'CountryCode','Country','TimePeriod','Value'};
    data.CountryCode = string(data.CountryCode);
    data.Value = str2double(string(data.Value));
    tokens = regexp(string(data.TimePeriod), '(\d+)-S(\d)', 'tokens');
    timeNumeric = zeros(height(data), 1);
    for i = 1:length(tokens)
        if ~isempty(tokens{i})
            y = str2double(tokens{i}{1}{1}); s = str2double(tokens{i}{1}{2});
            timeNumeric(i) = y + (s-1)*0.5; 
        else, timeNumeric(i) = NaN; end
    end
    data.TimeNumeric = timeNumeric;
    data = data(~isnan(data.Value) & ~isnan(data.TimeNumeric), :);
end

% 1. Selectam Tarile
code_perfect = "FR"; % Franta (Exemplu r ~ 1)
code_chaos   = "EL"; % Grecia (Exemplu r mai mic, "haos")

dataP = data(data.CountryCode == code_perfect, :);
dataC = data(data.CountryCode == code_chaos, :);

% 2. Calculam Corelatia si Regresia
% --- Franta ---
[R_p, P_p] = corrcoef(dataP.TimeNumeric, dataP.Value);
rho_p = R_p(1,2);
mdl_p = fitlm(dataP.TimeNumeric, dataP.Value);

% --- Grecia ---
[R_c, P_c] = corrcoef(dataC.TimeNumeric, dataC.Value);
rho_c = R_c(1,2);
mdl_c = fitlm(dataC.TimeNumeric, dataC.Value);

% 3. Vizualizare Comparativa
figure('Position', [100, 100, 1000, 500]);
tiledlayout(1, 2);

% Plot 1: Franta
nexttile;
scatter(dataP.TimeNumeric, dataP.Value, 50, 'filled', 'MarkerFaceColor', 'g');
hold on;
plot(mdl_p); % Linia de regresie
title(['Crestere "Perfecta": ' char(code_perfect)]);
subtitle(['r = ' num2str(rho_p, '%.2f') ' (Liniaritate puternica)']);
xlabel('An'); ylabel('Salariu (EUR)');
legend('off'); grid on;

% Plot 2: Grecia
nexttile;
scatter(dataC.TimeNumeric, dataC.Value, 50, 'filled', 'MarkerFaceColor', 'r');
hold on;
plot(mdl_c); % Linia de regresie
title(['Instabilitate / Criza: ' char(code_chaos)]);
subtitle(['r = ' num2str(rho_c, '%.2f') ' (Deviatii mari de la trend)']);
xlabel('An'); ylabel('Salariu (EUR)');
legend('off'); grid on;

% Explicatie in consola
fprintf('--- Interpretare Statistici ---\n');
fprintf('Tara %s (Franta): r = %.2f. Punctele stau lipite de linie.\n', code_perfect, rho_p);
fprintf('Tara %s (Grecia): r = %.2f. Observa "burta" din grafic (scaderea din 2012).\n', code_chaos, rho_c);
fprintf('Acea scadere face ca r sa fie mai mic (mai departe de 1).\n');